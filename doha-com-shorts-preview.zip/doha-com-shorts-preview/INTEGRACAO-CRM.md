# DOHA — projeto configurado para deploy

Página refeita com a estrutura da imagem de referência e com as fotos, os vídeos e a identidade da DOHA:

1. Abertura com texto e colagem de fotos da equipe.
2. Faixa de resultados.
3. Formulário com os passos de atendimento.
4. Depoimentos em vídeo, com o Shorts https://youtube.com/shorts/5n3C2NOcmG8 na primeira posição da grade de três, com miniatura e reprodução do YouTube.
5. Serviços em quatro cartões.
6. Perguntas frequentes.

## Publicar

Extraia o ZIP e abra um terminal na pasta do projeto. Com Node.js 22 ou superior:

```sh
npm ci
npm run deploy
```

Entre na sua conta quando solicitado e selecione o projeto existente do **somosdoha.com.br**. O comando publica a página e a função de integração do CRM. O token já está preenchido no arquivo privado `.env`, incluído no ZIP por sua autorização, e será empacotado como recurso privado da função. Nenhuma variável precisa ser preenchida manualmente.

O deploy deve usar a raiz completa do projeto. Arrastar somente `dist/` para uma hospedagem estática não publica a função do CRM. Se optar por enviar o projeto por Git, lembre que `.env` é ignorado para não expor o token no repositório; nesse fluxo, configure a variável privada na hospedagem. O comando de deploy acima usa os arquivos locais do ZIP completo.

## Abrir localmente

O site já está compilado em `dist/`. Execute:

```sh
npm start
```

Abra http://localhost:8787. Para editar, execute `npm run dev`; depois gere a nova compilação com `npm run build`.

## Integração pronta

O formulário envia para `/api/leads`. A função valida os campos e cria um registro em:

`https://hub-doha.base44.app/api/entities/Lead`

A autenticação usa `Authorization: Bearer` exclusivamente no servidor. Os arquivos públicos de `dist/` não contêm o token.

Nome, telefone, e-mail e empresa são enviados como `name`, `phone`, `email` e `company`. Os valores fixos são `origin: Meta Ads`, `status: lead`, `estimated_value: 0`, `has_capture: false` e `is_local: false`. Campanha, anúncio, segmento, faturamento e informação sobre tráfego pago ficam em `interactions`.

Nos anúncios, use `utm_campaign={{campaign.name}}&utm_content={{ad.name}}` para registrar campanha e anúncio. A mensagem de sucesso só aparece depois da confirmação de criação pelo CRM.

## Conferência

- 15 testes automatizados aprovados.
- Compilação, TypeScript e empacotamento da função aprovados.
- Carregamento do token na função de deploy conferido sem preenchimento manual de variáveis.
- Layout conferido no computador e no celular, sem transbordamento lateral.
- Navegação ao formulário e perguntas frequentes conferidas no navegador.

Os testes de criação usam respostas simuladas; nenhum lead foi criado no CRM real. A autenticação do token em consulta de leitura foi confirmada anteriormente. O pacote não foi publicado no domínio durante esta entrega.

Este ZIP contém a credencial real autorizada e destina-se ao seu site somosdoha.com.br. Quem receber o arquivo poderá acessar a credencial.
