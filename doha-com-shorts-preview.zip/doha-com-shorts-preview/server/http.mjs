import submitLead from './submitLead.js';

export async function handleLeadRequest(request, response) {
  response.status = function (code) { this.statusCode = code; return this; };
  response.json = function (body) {
    this.setHeader('Content-Type', 'application/json; charset=utf-8');
    this.setHeader('Cache-Control', 'no-store');
    this.end(JSON.stringify(body));
    return this;
  };
  try {
    if (request.method === 'POST') {
      const chunks = [];
      let size = 0;
      for await (const chunk of request) {
        size += chunk.length;
        if (size > 12000) {
          response.status(413).json({ success: false, error: 'Formulário muito grande.' });
          return;
        }
        chunks.push(chunk);
      }
      request.body = Buffer.concat(chunks).toString('utf8');
    }
    await submitLead(request, response);
  } catch {
    if (!response.writableEnded) response.status(500).json({ success: false, error: 'Não foi possível confirmar o envio.' });
  }
}
