import { createServer } from 'node:http';
import { createReadStream, existsSync } from 'node:fs';
import { readFile, stat } from 'node:fs/promises';
import { extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { handleLeadRequest } from './http.mjs';

const envPath = fileURLToPath(new URL('../.env', import.meta.url));
if (existsSync(envPath)) process.loadEnvFile(envPath);
const publicRoot = fileURLToPath(new URL('../dist/', import.meta.url));
const types = { '.mp4': 'video/mp4', '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8' };

createServer(async (request, response) => {
  try {
    const pathname = decodeURIComponent(new URL(request.url, 'http://localhost').pathname);
    if (pathname === '/api/leads') return await handleLeadRequest(request, response);
    if (pathname.startsWith('/api/')) { response.writeHead(404); response.end(); return; }
    if (!['GET', 'HEAD'].includes(request.method)) { response.writeHead(405, { Allow: 'GET, HEAD' }); response.end(); return; }
    let path = resolve(publicRoot, '.' + pathname);
    if (!path.startsWith(resolve(publicRoot) + sep) && path !== resolve(publicRoot)) {
      response.writeHead(403); response.end(); return;
    }
    try {
      if (!(await stat(path)).isFile()) path = resolve(publicRoot, 'index.html');
    } catch {
      if (extname(pathname)) { response.writeHead(404); response.end(); return; }
      path = resolve(publicRoot, 'index.html');
    }
    if (extname(path) === '.mp4') {
      const { size } = await stat(path);
      const range = request.headers.range;
      const headers = { 'Content-Type': 'video/mp4', 'Accept-Ranges': 'bytes' };
      let start = 0;
      let end = size - 1;
      if (range) {
        const match = /^bytes=(\d*)-(\d*)$/.exec(range);
        if (!match || (!match[1] && !match[2])) {
          response.writeHead(416, { 'Content-Range': `bytes */${size}` }); response.end(); return;
        }
        if (!match[1]) start = Math.max(0, size - Number(match[2]));
        else { start = Number(match[1]); if (match[2]) end = Math.min(end, Number(match[2])); }
        if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start > end || start >= size) {
          response.writeHead(416, { 'Content-Range': `bytes */${size}` }); response.end(); return;
        }
        headers['Content-Range'] = `bytes ${start}-${end}/${size}`;
      }
      headers['Content-Length'] = end - start + 1;
      response.writeHead(range ? 206 : 200, headers);
      if (request.method === 'HEAD') response.end();
      else { const stream = createReadStream(path, { start, end }); stream.on('error', () => response.destroy()); response.on('close', () => stream.destroy()); stream.pipe(response); }
      return;
    }
    const contents = await readFile(path);
    response.writeHead(200, { 'Content-Type': types[extname(path)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff' });
    response.end(request.method === 'HEAD' ? undefined : contents);
  } catch {
    if (!response.writableEnded) { response.writeHead(500); response.end('Não foi possível carregar a página.'); }
  }
}).listen(Number(process.env.PORT || 8787), process.env.HOST || '0.0.0.0', () => {
  console.log(`Site DOHA e integração CRM: http://localhost:${process.env.PORT || 8787}`);
});
