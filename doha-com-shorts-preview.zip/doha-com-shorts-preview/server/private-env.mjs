import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

// Private deployment resource. Only dist/ is published as browser assets.
export function loadPrivateEnvironment() {
  if (process.env.BASE44_ACCESS_TOKEN !== undefined) return;
  const paths = [resolve(process.cwd(), '.env'), fileURLToPath(new URL('../.env', import.meta.url))];
  for (const path of paths) {
    if (existsSync(path)) { process.loadEnvFile(path); return; }
  }
}
loadPrivateEnvironment();
