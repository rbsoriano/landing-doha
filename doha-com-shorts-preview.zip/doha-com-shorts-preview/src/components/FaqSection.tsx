import { useState } from "react";
import { Plus, X } from "lucide-react";
const faqs = [
  { question: "Como funciona a gestão de tráfego pago da DOHA?", answer: "Nossa equipe cuida da estratégia, dos criativos, da configuração das campanhas em Meta e Google Ads e da otimização contínua. Acompanhamos os indicadores para transformar o investimento em oportunidades para o seu restaurante." },
  { question: "Em quanto tempo eu vejo resultado?", answer: "O prazo depende do estágio do restaurante, da operação e do investimento. Nossa equipe avalia o seu cenário para definir metas e acompanhar a evolução dos resultados." },
  { question: "Preciso ter equipe de marketing própria?", answer: "Você conta com a equipe da DOHA para planejar e executar a estratégia. Na conversa inicial, alinhamos as necessidades do seu restaurante e a participação de cada pessoa no projeto." },
  { question: "A DOHA atende qualquer segmento de restaurante?", answer: "Atendemos pizzarias, hamburguerias, restaurantes e outros negócios de alimentação. Fale com nossa equipe para entender qual estratégia faz sentido para a sua operação." },
];
const FaqSection = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  return <section id="faq" className="doha-faq"><div className="doha-wrap doha-faq-grid"><div><span className="doha-kicker doha-kicker-line">PERGUNTAS FREQUENTES</span><h2>Antes de falar com a gente</h2></div><div className="doha-faq-list">{faqs.map((item, i) => <article className="doha-faq-item" key={item.question}><h3><button aria-expanded={openIndex === i} aria-controls={`faq-answer-${i}`} onClick={() => setOpenIndex(openIndex === i ? null : i)}>{item.question}{openIndex === i ? <X size={16} /> : <Plus size={16} />}</button></h3><div id={`faq-answer-${i}`} hidden={openIndex !== i}><p>{item.answer}</p></div></article>)}</div></div></section>;
};
export default FaqSection;
