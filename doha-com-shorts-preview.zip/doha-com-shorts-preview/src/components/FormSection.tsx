declare global {
  interface Window {
    fbq: (...args: any[]) => void;
  }
}

import { useRef, useState } from "react";
import { ArrowRight, CheckCircle, ShieldCheck } from "lucide-react";
import { submitLeadForm } from "@/lib/formSubmit";

const segmentos = [
  "Pizzarias", "Hamburguerias", "Churrascarias / Steakhouses",
  "Restaurante Japonês / Asiáticos", "Restaurante de massas e comida italiana",
  "Restaurante de comidas brasileiras", "Outros",
];
const faturamentos = [
  "Até 20 mil", "De 20 mil até 40 mil", "De 40 mil até 60 mil",
  "De 60 mil até 80 mil", "De 80 mil até 100 mil", "De 100 mil até 150 mil",
  "De 150 mil até 250 mil", "De 250 mil até 400 mil", "De 400 mil até 600 mil",
  "De 600 mil até 1 milhão", "Mais de 1 milhão",
];

const FormSection = () => {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const sending = useRef(false);
  const [form, setForm] = useState({
    nome: "", email: "", telefone: "", nome_empresa: "",
    faturamento_mensal: "", segmento: "",
    ja_investiu_trafego: null as boolean | null,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    let { name, value } = e.target;
    if (name === "telefone") {
      const digits = value.replace(/\D/g, "").slice(0, 11);
      value = digits.length > 2 ? `(${digits.slice(0, 2)}) ${digits.slice(2)}` : digits;
      if (digits.length > 6) {
        const split = digits.length === 11 ? 7 : 6;
        value = `(${digits.slice(0, 2)}) ${digits.slice(2, split)}-${digits.slice(split)}`;
      }
    }
    setForm((previous) => ({ ...previous, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (sending.current || submitted) return;
    if (!form.nome.trim() || !form.email.trim() || !form.telefone || !form.nome_empresa.trim() || !form.faturamento_mensal || !form.segmento || form.ja_investiu_trafego === null) {
      setError("Preencha todos os campos."); return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) {
      setError("Por favor, insira um e-mail válido."); return;
    }
    if (!/^\d{10,11}$/.test(form.telefone.replace(/\D/g, ""))) {
      setError("Por favor, insira um número de telefone válido com DDD."); return;
    }
    sending.current = true;
    setLoading(true); setError("");
    try {
      await submitLeadForm({ ...form, ja_investiu_trafego: form.ja_investiu_trafego });
      setSubmitted(true);
      try {
        if (typeof window.fbq === "function") window.fbq("track", "Lead");
      } catch {
        // Tracking must not undo a confirmed CRM submission.
      }
    } catch {
      setError("Não foi possível confirmar o envio. Por favor, tente novamente em alguns instantes.");
    } finally {
      sending.current = false;
      setLoading(false);
    }
  };

  return (
    <section id="formulario" className="lead-hero doha-form-section" aria-labelledby="lead-title">
      <div className="doha-wrap lead-hero-layout">
        <div className="lead-intro">
          <span className="doha-kicker doha-kicker-line">ATENÇÃO</span>
          <h2 id="lead-title">FALTAM POUCOS SEGUNDOS PARA VOCÊ MUDAR A REALIDADE DO SEU RESTAURANTE</h2>
          <div className="doha-steps">
            <article><span>1</span><div><h3>Complete o formulário</h3><p>Preencha suas informações ao lado. Seus dados serão usados apenas para o nosso contato.</p></div></article>
            <article><span>2</span><div><h3>Converse com um especialista</h3><p>Nossa equipe entrará em contato para entender seu restaurante e apresentar os próximos passos.</p></div></article>
          </div>
        </div>
        <div className="lead-form-card">
          {submitted ? (
            <div className="lead-success" role="status">
              <CheckCircle size={48} className="text-primary mx-auto mb-4" />
              <h2>Recebemos sua solicitação!</h2>
              <p>Nossa equipe entrará em contato com você em breve.</p>
              <span>Fique atento ao seu telefone e e-mail.</span>
            </div>
          ) : (
            <form onSubmit={handleSubmit} aria-label="Receber mais informações" aria-busy={loading}>
              <div className="lead-form-heading"><h2>Falar com um especialista</h2><p>Leva menos de 1 minuto.</p></div>
              <div className="lead-fields">
                <div><label htmlFor="nome">Nome</label><input id="nome" name="nome" autoComplete="name" type="text" placeholder="Seu nome" value={form.nome} onChange={handleChange} /></div>
                <div><label htmlFor="nome_empresa">Empresa</label><input id="nome_empresa" name="nome_empresa" autoComplete="organization" type="text" placeholder="Nome da empresa" value={form.nome_empresa} onChange={handleChange} /></div>
                <div><label htmlFor="email">E-mail</label><input id="email" name="email" autoComplete="email" type="email" placeholder="Seu melhor e-mail" value={form.email} onChange={handleChange} /></div>
                <div><label htmlFor="telefone">Telefone</label><input id="telefone" name="telefone" autoComplete="tel-national" type="tel" inputMode="tel" placeholder="Telefone" value={form.telefone} onChange={handleChange} /></div>
                <div><label htmlFor="segmento">Segmento</label><select id="segmento" name="segmento" value={form.segmento} onChange={handleChange}><option value="">Seu segmento</option>{segmentos.map((item) => <option key={item} value={item}>{item}</option>)}</select></div>
                <div><label htmlFor="faturamento_mensal">Faturamento mensal</label><select id="faturamento_mensal" name="faturamento_mensal" value={form.faturamento_mensal} onChange={handleChange}><option value="">Seu faturamento</option>{faturamentos.map((item) => <option key={item} value={item}>{item}</option>)}</select></div>
              </div>
              <fieldset className="lead-traffic"><legend>Já investiu em tráfego pago?</legend><div>{[true, false].map((value) => <button type="button" key={String(value)} aria-pressed={form.ja_investiu_trafego === value} onClick={() => setForm((previous) => ({ ...previous, ja_investiu_trafego: value }))}>{value ? "Sim" : "Não"}</button>)}</div></fieldset>
              {error && <p role="alert" className="text-destructive text-sm mb-3">{error}</p>}
              <button type="submit" disabled={loading} className="lead-submit">{loading ? "Enviando..." : "Receber mais informações"}{!loading && <ArrowRight size={19} />}</button>
              <p className="lead-privacy"><ShieldCheck size={14} /> Seus dados serão usados apenas para contato.</p>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};
export default FormSection;
