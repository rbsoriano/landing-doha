import { ArrowRight } from "lucide-react";
import teamPhoto from "@/assets/857bfa55-ec52-4247-b8dd-d8422af77582-Photoroom.webp";
import officePhoto from "@/assets/FOTOS DOHA (3).webp";
import culturePhoto from "@/assets/6.webp";

const HeroSection = () => (
  <>
    <section className="doha-hero" aria-labelledby="hero-title">
      <div className="doha-wrap doha-hero-grid">
        <div className="doha-hero-copy">
          <h1 id="hero-title">SEU RESTAURANTE PRECISA DE UMA ASSESSORIA QUE <span>ENTENDE DE FOODSERVICE.</span></h1>
          <p>Marketing para quem vive a gastronomia. Fale com um especialista e conheça o método que a DOHA aplica para transformar estratégia em resultado.</p>
          <a className="doha-button" href="#formulario">Falar com um especialista <ArrowRight size={17} /></a>
        </div>
        <div className="doha-collage" aria-label="Conheça o time e o escritório da DOHA">
          <figure className="doha-polaroid doha-photo-main"><img src={teamPhoto} alt="Time DOHA trabalhando no escritório" fetchPriority="high" width="766" height="1024" /><figcaption>TIME DOHA</figcaption></figure>
          <div className="doha-photo-bottom">
            <figure className="doha-polaroid doha-photo-office"><img src={officePhoto} alt="Reunião de estratégia no escritório DOHA" width="1080" height="1350" /><figcaption>ESCRITÓRIO</figcaption></figure>
            <figure className="doha-polaroid doha-photo-culture"><img src={culturePhoto} alt="Profissionais da DOHA construindo estratégias para clientes" width="1080" height="1350" /><figcaption>NOSSA CULTURA</figcaption></figure>
          </div>
        </div>
      </div>
    </section>
    <div className="doha-marquee" aria-label="Mais de 10 clientes ativos. Mais de 2 milhões em vendas para nossos clientes. Mais de 5 anos de experiência."><div>{[0, 1, 2].map((copy) => <span key={copy} aria-hidden="true">+10 CLIENTES ATIVOS <b>✦</b> +2M EM VENDAS PARA OS NOSSOS CLIENTES <b>✦</b> +5 ANOS DE EXPERIÊNCIA <b>✦</b> </span>)}</div></div>
  </>
);
export default HeroSection;
