import logoDoha from "@/assets/logo-doha.webp";
const Navbar = () => <header className="doha-header"><div className="doha-wrap"><a href="#" aria-label="DOHA — início" className="doha-brand"><img src={logoDoha} alt="" width="36" height="36" /><span>doha<span className="doha-brand-dot">.</span></span></a></div></header>;
export default Navbar;
