import { Play } from "lucide-react";
import { useState } from "react";

const testimonials = [
  { id: "5n3C2NOcmG8", name: "Depoimento Açaí Arretado", thumbnail: "https://i.ytimg.com/vi/5n3C2NOcmG8/frame0.jpg" },
  { id: "qzLQcjk-b9Y", name: "Depoimento Exclusivo" },
  { id: "46K6ry5QLXI", name: "Depoimento de Sucesso" },
];
const TestimonialsSection = () => {
  const [playingId, setPlayingId] = useState<string | null>(null);
  return <section id="depoimentos" className="doha-testimonials"><div className="doha-wrap">
    <div className="doha-section-heading"><span className="doha-kicker">DEPOIMENTOS</span><h2>Restaurantes com resultado.<br />Isso é DOHA.</h2><p>Restaurantes reais, resultado real com estratégias feitas pela nossa equipe.</p></div>
    <div className="doha-video-grid">{testimonials.map((item, i) => <article className="doha-video" key={item.id}>
      {playingId === item.id ? <iframe src={`https://www.youtube.com/embed/${item.id}?autoplay=1&rel=0`} title={item.name} allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen /> : <button className="doha-video-cover" aria-label={`Assistir ${item.name}`} onClick={() => setPlayingId(item.id)}>
        <img src={item.thumbnail || `https://img.youtube.com/vi/${item.id}/hqdefault.jpg`} alt={item.name} loading="lazy" width={i === 0 ? 268 : 480} height={i === 0 ? 480 : 360} />
        <span className="doha-video-badge">{i === 0 ? "Resultado real" : "Cliente DOHA"}</span><span className="doha-video-play"><Play size={24} fill="currentColor" /></span><span className="doha-video-caption"><strong>{item.name}</strong><small>Restaurante parceiro</small></span>
      </button>}
    </article>)}</div>
  </div></section>;
};
export default TestimonialsSection;
