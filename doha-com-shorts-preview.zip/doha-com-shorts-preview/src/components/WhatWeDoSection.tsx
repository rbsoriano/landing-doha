import { UsersRound, Instagram, Store, ChartNoAxesCombined } from "lucide-react";
const services = [
  { Icon: UsersRound, title: "Gestão e atendimento", text: "Um time da DOHA acompanha seu restaurante de perto, do primeiro contato ao suporte do dia a dia." },
  { Icon: Instagram, title: "Mídia paga", text: "Campanhas de Meta e Google Ads geridas e otimizadas pela nossa equipe, com foco em quem tem potencial para comprar." },
  { Icon: Store, title: "Soluções comerciais para restaurantes", text: "Estratégias para aumentar o ticket médio, otimizar seu cardápio digital e melhorar a performance do seu iFood." },
  { Icon: ChartNoAxesCombined, title: "Relatórios e acompanhamento", text: "Você acompanha os indicadores, os resultados das campanhas e os próximos passos da estratégia do seu restaurante." },
];
const WhatWeDoSection = () => <section id="servicos" className="doha-services"><div className="doha-wrap"><div className="doha-services-heading"><span className="doha-kicker doha-kicker-line">O QUE FAZEMOS</span><h2>A DOHA estrutura o marketing<br className="hidden md:block" /> do seu restaurante a partir da<br className="hidden md:block" /> sua necessidade</h2><p>Cada real investido passa pela nossa equipe, do criativo ao relatório de resultado.</p></div><div className="doha-service-grid">{services.map(({Icon, title, text}) => <article className="doha-service-card" key={title}><span className="doha-service-icon"><Icon size={21} /></span><h3>{title}</h3><p>{text}</p></article>)}</div></div></section>;
export default WhatWeDoSection;
