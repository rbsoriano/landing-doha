import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import "./landing.css";
import { captureAttribution } from "./lib/formSubmit";

captureAttribution();

createRoot(document.getElementById("root")!).render(<App />);
