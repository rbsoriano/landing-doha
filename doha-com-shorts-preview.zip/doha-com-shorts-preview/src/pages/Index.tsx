import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import FormSection from "@/components/FormSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import WhatWeDoSection from "@/components/WhatWeDoSection";
import FaqSection from "@/components/FaqSection";
const Index = () => <main className="doha-page"><Navbar /><HeroSection /><FormSection /><TestimonialsSection /><WhatWeDoSection /><FaqSection /><footer className="doha-footer"><div className="doha-wrap"><a className="doha-footer-brand" href="#">DOHA</a><span>Assessoria DOHA · Marketing para restaurantes</span><a href="https://www.instagram.com/somosdoha" target="_blank" rel="noopener noreferrer">Instagram ↗</a></div></footer></main>;
export default Index;
