import { afterEach, beforeEach, test } from 'node:test';
import assert from 'node:assert/strict';
import handler from '../server/submitLead.js';

const originalFetch = globalThis.fetch;
const originalToken = process.env.BASE44_ACCESS_TOKEN;
const originalConsoleError = console.error;
const form = {
  nome: 'Felipe Teste', email: 'teste@example.com', telefone: '(83) 99999-9999',
  nome_empresa: 'Empresa Teste', segmento: 'Pizzarias', faturamento_mensal: 'Até 20 mil',
  ja_investiu_trafego: false, campanha: 'Campanha 1', anuncio: 'Anuncio 1',
};
let calls;
beforeEach(() => {
  process.env.BASE44_ACCESS_TOKEN = 'test-server-token';
  calls = [];
  console.error = () => {};
  globalThis.fetch = async (...args) => {
    calls.push(args);
    return new Response(JSON.stringify({ id: 'test-lead-id' }), { status: 201 });
  };
});
afterEach(() => {
  globalThis.fetch = originalFetch;
  console.error = originalConsoleError;
  if (originalToken === undefined) delete process.env.BASE44_ACCESS_TOKEN;
  else process.env.BASE44_ACCESS_TOKEN = originalToken;
});
async function request(body = form, overrides = {}) {
  const req = { method: 'POST', headers: { 'content-type': 'application/json', host: 'site.example', origin: 'https://site.example' }, body, ...overrides };
  const res = { headers: {}, statusCode: 200, setHeader(k, v) { this.headers[k] = v; }, status(code) { this.statusCode = code; return this; }, json(body) { this.body = body; return this; } };
  await handler(req, res);
  return res;
}
test('creates the exact CRM fields with a private bearer token and preserves qualification', async () => {
  const res = await request({ ...form, status: 'won', estimated_value: 999 });
  assert.equal(res.statusCode, 201);
  assert.deepEqual(res.body, { success: true });
  const [url, options] = calls[0];
  assert.equal(url, 'https://hub-doha.base44.app/api/entities/Lead');
  assert.equal(options.headers.Authorization, 'Bearer test-server-token');
  assert.deepEqual(JSON.parse(options.body), {
    name: form.nome, phone: form.telefone, email: form.email, company: form.nome_empresa,
    origin: 'Meta Ads', status: 'lead', estimated_value: 0, has_capture: false, is_local: false,
    interactions: 'Meta Ads | Campanha 1 | Anuncio 1\nSegmento: Pizzarias\nFaturamento mensal: Até 20 mil\nJá investiu em tráfego pago: Não',
  });
  assert.equal(calls.length, 1);
  assert.ok(!JSON.stringify(res.body).includes('test-server-token'));
});
test('rejects invalid forms before contacting the CRM', async () => {
  for (const body of [{ ...form, nome: ' ' }, { ...form, email: 'invalid' }, { ...form, telefone: '123' }, { ...form, ja_investiu_trafego: 'false' }, null, '{bad json']) {
    assert.equal((await request(body)).statusCode, 400);
  }
  assert.equal(calls.length, 0);
});
test('rejects methods, content types, foreign origins and oversized input', async () => {
  assert.equal((await request(form, { method: 'GET' })).statusCode, 405);
  assert.equal((await request(form, { headers: {} })).statusCode, 415);
  assert.equal((await request(form, { headers: { origin: 'https://foreign.example', host: 'site.example' } })).statusCode, 403);
  assert.equal((await request({ ...form, extra: 'a'.repeat(13000) })).statusCode, 413);
  assert.equal(calls.length, 0);
});
test('does not report success when the token is missing', async () => {
  process.env.BASE44_ACCESS_TOKEN = '';
  assert.equal((await request()).statusCode, 503);
  assert.equal(calls.length, 0);
});
test('handles missing attribution without placeholder variables', async () => {
  await request({ ...form, campanha: '', anuncio: '' });
  assert.match(JSON.parse(calls[0][1].body).interactions, /^Meta Ads \| Campanha não informada \| Anúncio não informado/);
});
test('does not leak upstream errors or retry a failed write', async () => {
  for (const status of [401, 403, 429, 500]) {
    calls = [];
    globalThis.fetch = async (...args) => { calls.push(args); return new Response('private upstream details', { status }); };
    const res = await request();
    assert.equal(res.statusCode, 502);
    assert.equal(res.body.success, false);
    assert.ok(!JSON.stringify(res.body).includes('private upstream details'));
    assert.equal(calls.length, 1);
  }
});
test('requires a CRM confirmation and handles timeouts or invalid JSON', async () => {
  for (const response of [new Response('{}'), new Response('<html>error</html>')]) {
    globalThis.fetch = async () => response;
    assert.equal((await request()).statusCode, 502);
  }
  globalThis.fetch = async () => { throw new DOMException('timeout', 'TimeoutError'); };
  assert.equal((await request()).statusCode, 502);
});
test('Netlify function accepts a native web Request and returns a JSON confirmation', async () => {
  const { default: netlifyHandler } = await import('../netlify/functions/leads.mjs');
  const response = await netlifyHandler(new Request('https://somosdoha.com.br/api/leads', {
    method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://somosdoha.com.br' }, body: JSON.stringify(form),
  }));
  assert.equal(response.status, 201);
  assert.equal(response.headers.get('cache-control'), 'no-store');
  assert.deepEqual(await response.json(), { success: true });
  assert.equal(calls.length, 1);
});
test('Netlify function rejects foreign origins and supports method validation', async () => {
  const { default: netlifyHandler } = await import('../netlify/functions/leads.mjs');
  assert.equal((await netlifyHandler(new Request('https://somosdoha.com.br/api/leads'))).status, 405);
  assert.equal((await netlifyHandler(new Request('https://somosdoha.com.br/api/leads', {
    method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://foreign.example' }, body: JSON.stringify(form),
  }))).status, 403);
  assert.equal(calls.length, 0);
});
