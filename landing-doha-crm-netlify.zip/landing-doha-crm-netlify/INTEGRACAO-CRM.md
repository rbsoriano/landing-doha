# Integração do formulário DOHA com o CRM

O código foi preparado para a hospedagem **Netlify**, no site `https://somosdoha.com.br`.

## Ativar no site existente

1. Extraia este projeto e atualize os arquivos no repositório que a Netlify usa para publicar o site. Mantenha `netlify.toml`, a pasta `netlify/functions/` e a pasta `server/` na raiz do projeto, junto de `package.json`.
2. No painel do projeto da Netlify, abra **Project configuration → Environment variables → Add a variable**.
3. Crie a variável **`BASE44_ACCESS_TOKEN`** e coloque o token de acesso do Base44 no valor. Se houver seleção de escopo, inclua **Functions**; aplique ao contexto **Production**. O token não está incluído neste ZIP. Ele nunca deve receber o prefixo `VITE_`.
4. Faça uma nova publicação em **Deploys → Trigger deploy** depois de salvar a variável. As configurações incluídas usam `npm run build`, publicam `dist` e empacotam a função do servidor automaticamente.
5. Abra o site, preencha o formulário com um contato de teste identificável e confira o cadastro no CRM. A mensagem “Recebemos sua solicitação!” só aparece depois da confirmação do CRM.

A atualização exige uma publicação com a função do servidor. Enviar somente os arquivos estáticos de `dist` por arrastar e soltar não publica essa integração. Se o projeto atual usa deploy manual, publique a raiz completa pelo Netlify CLI, incluindo funções, ou conecte o repositório à Netlify. Pelo CLI, execute na raiz do projeto (selecione o projeto já existente ao vincular):

```sh
npx netlify login
npx netlify link
npx netlify deploy --build --prod
```

## O que acontece no envio

O navegador envia os campos para `/api/leads`, no mesmo domínio do site. A Netlify encaminha para a função `leads`, que valida o formulário e cria um registro por POST em:

`https://hub-doha.base44.app/api/entities/Lead`

A autenticação é feita exclusivamente no servidor por `Authorization: Bearer`, usando a variável privada.

| Campo no CRM | Valor enviado |
| --- | --- |
| `name` | Nome do formulário |
| `phone` | Telefone do formulário |
| `email` | E-mail do formulário |
| `company` | Nome da empresa |
| `origin` | `Meta Ads` |
| `status` | `lead` |
| `estimated_value` | `0` |
| `has_capture` | `false` |
| `is_local` | `false` |
| `interactions` | `Meta Ads \| campanha \| anúncio`, seguido de segmento, faturamento mensal e informação sobre investimento em tráfego |

A origem permanece `Meta Ads` para todos os envios, conforme a configuração solicitada. Os demais dados de qualificação são preservados em `interactions`, porque não foram fornecidos campos específicos para eles no CRM. O antigo Google Apps Script não é mais chamado pelo formulário.

## Campanha e anúncio

Configure estes parâmetros no endereço de destino do anúncio na Meta:

```text
utm_source=facebook&utm_medium=paid_social&utm_campaign={{campaign.name}}&utm_content={{ad.name}}
```

O site lê campanha de `utm_campaign` e anúncio de `utm_content`. Também aceita `campaign_name`/`campanha` e `ad_name`/`anuncio`. Guarda essa atribuição durante a sessão, mesmo se a pessoa navegar antes de enviar o formulário.

Exemplo de endereço para testar a captura:

```text
https://somosdoha.com.br/?utm_campaign=Teste%20Doha&utm_content=Video%201#formulario
```

Quando o link não traz campanha ou anúncio, o CRM recebe “Campanha não informada” ou “Anúncio não informado”, respectivamente.

## Validação realizada

- Autenticação no endpoint real: HTTP 200 em uma consulta de leitura. Nenhum lead real ou fictício foi criado nesta verificação.
- Testes automatizados da função e do formulário: envio dos campos, atribuição, confirmação do CRM, cliques repetidos, validação, falhas de autenticação, rede e timeout.
- Compilação de produção e verificação TypeScript.

Os testes de criação usam respostas simuladas. A criação de ponta a ponta no CRM precisa ser verificada após a publicação. A autenticação de leitura não comprova permissão de criação; se o CRM responder 403, revise as permissões de escrita do token no aplicativo.

O código evita repetição automática de POST. Se houver perda de conexão depois de o CRM salvar o cadastro, o resultado pode ficar incerto; antes de reenviar manualmente, verifique se o registro já chegou ao CRM.

## Desenvolvimento local

```sh
npm ci
npm test
npm run test:api
npm run build
```

Para testar o formulário com a função local, use `npx netlify dev` na raiz do projeto e configure `BASE44_ACCESS_TOKEN` no ambiente local. `npm run dev` sozinho serve apenas a interface.

## Referências

- [Tokens pessoais do Base44 e cabeçalho de autenticação](https://docs.base44.com/Workspaces/Personal-access-tokens)
- [Funções da Netlify](https://docs.netlify.com/build/functions/overview/)
- [Variáveis privadas para funções da Netlify](https://docs.netlify.com/build/functions/environment-variables/)
