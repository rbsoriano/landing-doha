# Landing page DOHA

Site React, TypeScript e Vite com integração do formulário ao CRM Base44 por uma função privada da Netlify.

Veja **[INTEGRACAO-CRM.md](INTEGRACAO-CRM.md)** para configurar o token, publicar e conferir os leads.

```sh
npm ci
npm test
npm run test:api
npm run build
```

A função do servidor lê `BASE44_ACCESS_TOKEN`. O token não acompanha o projeto e não deve ser incluído no código do navegador.
