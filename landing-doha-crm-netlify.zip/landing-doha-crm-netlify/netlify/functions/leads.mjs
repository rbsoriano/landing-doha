import submitLead from "../../server/submitLead.js";

export default async function handler(request) {
  const headers = Object.fromEntries(request.headers);
  // Netlify's Request URL remains authoritative if Host is not included.
  headers.host = new URL(request.url).host;
  const req = {
    method: request.method,
    headers,
    body: request.method === "POST" ? await request.text() : undefined,
  };
  const responseHeaders = new Headers();
  let response;
  const res = {
    statusCode: 200,
    setHeader(name, value) { responseHeaders.set(name, value); },
    status(code) { this.statusCode = code; return this; },
    json(body) {
      response = Response.json(body, { status: this.statusCode, headers: responseHeaders });
      return this;
    },
  };
  await submitLead(req, res);
  return response;
}
