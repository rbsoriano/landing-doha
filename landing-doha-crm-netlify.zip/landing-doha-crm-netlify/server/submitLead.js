const CRM_URL = "https://hub-doha.base44.app/api/entities/Lead";

function text(value, maxLength) {
  return typeof value === "string" ? value.trim().replace(/[\r\n]+/g, " ").slice(0, maxLength) : "";
}

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ success: false, error: "Método não permitido." });
  }
  // Prevent cross-origin browser submissions; this is still a public form endpoint.
  if (req.headers.origin) {
    try {
      if (new URL(req.headers.origin).host !== req.headers.host) {
        return res.status(403).json({ success: false, error: "Origem não permitida." });
      }
    } catch {
      return res.status(403).json({ success: false, error: "Origem não permitida." });
    }
  }
  if (!req.headers["content-type"]?.toLowerCase().startsWith("application/json")) {
    return res.status(415).json({ success: false, error: "Envie os dados em JSON." });
  }
  let data;
  try {
    data = typeof req.body === "string" ? JSON.parse(req.body) : req.body;
    if (!data || typeof data !== "object" || Array.isArray(data)) throw new Error();
    if (Buffer.byteLength(JSON.stringify(data)) > 12000) {
      return res.status(413).json({ success: false, error: "Formulário muito grande." });
    }
  } catch {
    return res.status(400).json({ success: false, error: "Dados inválidos." });
  }
  const name = text(data.nome, 200);
  const email = text(data.email, 254);
  const phone = text(data.telefone, 40);
  const company = text(data.nome_empresa, 200);
  const segmento = text(data.segmento, 200);
  const faturamento = text(data.faturamento_mensal, 200);
  const phoneDigits = phone.replace(/\D/g, "");
  if (!name || !company || !segmento || !faturamento ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
      !/^\d{10,11}$/.test(phoneDigits) || typeof data.ja_investiu_trafego !== "boolean") {
    return res.status(400).json({ success: false, error: "Preencha todos os campos corretamente." });
  }
  const token = process.env.BASE44_ACCESS_TOKEN?.trim();
  if (!token) {
    console.error("CRM integration: BASE44_ACCESS_TOKEN is not configured.");
    return res.status(503).json({ success: false, error: "Envio indisponível no momento." });
  }
  const campanha = text(data.campanha, 300) || "Campanha não informada";
  const anuncio = text(data.anuncio, 300) || "Anúncio não informado";
  const lead = {
    name,
    phone,
    email,
    company,
    origin: "Meta Ads",
    status: "lead",
    estimated_value: 0,
    has_capture: false,
    is_local: false,
    interactions: [
      `Meta Ads | ${campanha} | ${anuncio}`,
      `Segmento: ${segmento}`,
      `Faturamento mensal: ${faturamento}`,
      `Já investiu em tráfego pago: ${data.ja_investiu_trafego ? "Sim" : "Não"}`,
    ].join("\n"),
  };
  try {
    const response = await fetch(CRM_URL, {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify(lead),
      signal: AbortSignal.timeout(15000),
      redirect: "error",
    });
    if (!response.ok) {
      // Never log the response body, token or personal data.
      console.error("CRM integration: upstream HTTP", response.status);
      return res.status(502).json({ success: false, error: "Não foi possível registrar no CRM." });
    }
    const created = await response.json();
    if (!created || typeof created.id !== "string" || !created.id) {
      console.error("CRM integration: missing lead confirmation.");
      return res.status(502).json({ success: false, error: "Não foi possível confirmar o cadastro." });
    }
    return res.status(201).json({ success: true });
  } catch {
    console.error("CRM integration: request failed or timed out.");
    return res.status(502).json({ success: false, error: "Não foi possível confirmar o cadastro." });
  }
}
