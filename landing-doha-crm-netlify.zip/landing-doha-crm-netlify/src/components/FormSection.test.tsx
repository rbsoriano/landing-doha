import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, expect, it, vi } from "vitest";
import FormSection from "./FormSection";

const { submit } = vi.hoisted(() => ({ submit: vi.fn() }));
vi.mock("@/lib/formSubmit", () => ({ submitLeadForm: submit }));
afterEach(() => { cleanup(); vi.clearAllMocks(); delete window.fbq; });
function fillForm(container: HTMLElement) {
  for (const [name, value] of Object.entries({ nome: "Felipe Teste", email: "teste@example.com", telefone: "83999999999", nome_empresa: "Empresa Teste", segmento: "Pizzarias", faturamento_mensal: "Até 20 mil" })) {
    fireEvent.change(container.querySelector(`[name="${name}"]`)!, { target: { value } });
  }
  fireEvent.click(screen.getByRole("button", { name: "Não" }));
}
it("waits for CRM confirmation before showing success and firing the Meta event", async () => {
  let confirm: () => void;
  submit.mockImplementation(() => new Promise<void>((resolve) => { confirm = resolve; }));
  window.fbq = vi.fn();
  const { container } = render(<FormSection />);
  fillForm(container);
  fireEvent.submit(container.querySelector("form")!);
  fireEvent.submit(container.querySelector("form")!);
  expect(submit).toHaveBeenCalledTimes(1);
  expect(screen.queryByText("Recebemos sua solicitação!")).not.toBeInTheDocument();
  expect(window.fbq).not.toHaveBeenCalled();
  expect(screen.getByRole("button", { name: /Enviando/ })).toBeDisabled();
  confirm!();
  await screen.findByText("Recebemos sua solicitação!");
  expect(window.fbq).toHaveBeenCalledWith("track", "Lead");
});
it("keeps the filled form and skips the Meta event when the CRM rejects the submission", async () => {
  submit.mockRejectedValue(new Error("CRM unavailable"));
  window.fbq = vi.fn();
  const { container } = render(<FormSection />);
  fillForm(container);
  fireEvent.submit(container.querySelector("form")!);
  await screen.findByRole("alert");
  expect(screen.getByPlaceholderText("Seu nome")).toHaveValue("Felipe Teste");
  expect(screen.queryByText("Recebemos sua solicitação!")).not.toBeInTheDocument();
  expect(window.fbq).not.toHaveBeenCalled();
  await waitFor(() => expect(screen.getByRole("button", { name: "Receber mais informações" })).toBeEnabled());
});
