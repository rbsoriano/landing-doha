import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { captureAttribution, submitLeadForm } from "./formSubmit";

const form = {
  nome: "Felipe Teste", email: "teste@example.com", telefone: "(83) 99999-9999",
  nome_empresa: "Empresa Teste", segmento: "Pizzarias", faturamento_mensal: "Até 20 mil",
  ja_investiu_trafego: false,
};

beforeEach(() => {
  sessionStorage.clear();
  window.history.replaceState(null, "", "/");
});
afterEach(() => vi.unstubAllGlobals());

describe("CRM form submission", () => {
  it("sends fields and campaign attribution to the local server", async () => {
    window.history.replaceState(null, "", "/?utm_campaign=Restaurantes&utm_content=Video%201");
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({ success: true }), { status: 201 }));
    vi.stubGlobal("fetch", fetchMock);
    await submitLeadForm(form);
    const [url, options] = fetchMock.mock.calls[0];
    expect(url).toBe("/api/leads");
    expect(JSON.parse(options.body)).toEqual({ ...form, campanha: "Restaurantes", anuncio: "Video 1" });
    expect(options.headers).toEqual({ "Content-Type": "application/json" });
  });
  it("keeps campaign attribution when the visitor navigates", () => {
    window.history.replaceState(null, "", "/?utm_campaign=Campanha&utm_content=Anuncio");
    captureAttribution();
    window.history.replaceState(null, "", "/outra-pagina");
    expect(captureAttribution()).toEqual({ campanha: "Campanha", anuncio: "Anuncio" });
  });
  it("does not claim success for an HTML page, CRM rejection or network error", async () => {
    for (const response of [new Response("<html>site</html>"), new Response(JSON.stringify({ success: false }), { status: 502 })]) {
      const fetchMock = vi.fn().mockResolvedValue(response);
      vi.stubGlobal("fetch", fetchMock);
      await expect(submitLeadForm(form)).rejects.toThrow();
      expect(fetchMock).toHaveBeenCalledTimes(1);
    }
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("offline")));
    await expect(submitLeadForm(form)).rejects.toThrow();
  });
});
