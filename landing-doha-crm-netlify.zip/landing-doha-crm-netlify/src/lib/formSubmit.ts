export type LeadFormData = {
  nome: string;
  email: string;
  telefone: string;
  nome_empresa: string;
  faturamento_mensal: string;
  segmento: string;
  ja_investiu_trafego: boolean;
};

type Attribution = { campanha: string; anuncio: string };
const ATTRIBUTION_KEY = "doha-lead-attribution";

// Keep attribution during this visit even if the URL changes before submission.
export function captureAttribution(): Attribution {
  const params = new URLSearchParams(window.location.search);
  const read = (...keys: string[]) => keys.map((key) => params.get(key)?.trim()).find(Boolean)?.slice(0, 300) || "";
  const current = {
    campanha: read("utm_campaign", "campaign_name", "campanha"),
    anuncio: read("utm_content", "ad_name", "anuncio"),
  };
  try {
    if (current.campanha || current.anuncio) {
      window.sessionStorage.setItem(ATTRIBUTION_KEY, JSON.stringify(current));
      return current;
    }
    const saved = JSON.parse(window.sessionStorage.getItem(ATTRIBUTION_KEY) || "null");
    if (saved && typeof saved.campanha === "string" && typeof saved.anuncio === "string") return saved;
  } catch {
    // Submission still works when browser storage is unavailable.
  }
  return current;
}

export async function submitLeadForm(form: LeadFormData): Promise<void> {
  const response = await fetch("/api/leads", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...form, ...captureAttribution() }),
  });
  const result = await response.json().catch(() => null);
  if (!response.ok || result?.success !== true) {
    throw new Error("Não foi possível confirmar o envio. Tente novamente em alguns instantes.");
  }
}
