import { ChevronUp } from "lucide-react";
import logoDoha from "@/assets/logo-doha.webp";

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-primary">
      <div className="container py-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <img src={logoDoha} alt="DOHA" className="w-10 h-10 rounded-lg object-cover" />
            <span className="font-heading font-bold text-lg text-primary-foreground">DOHA</span>
          </div>

          <div className="flex items-center gap-4">
            <a
              href="https://www.instagram.com/somosdoha"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary-foreground/80 hover:text-primary-foreground transition-colors duration-300"
              aria-label="Instagram da DOHA"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
              </svg>
            </a>

            <button
              onClick={scrollToTop}
              className="text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors duration-300 flex items-center gap-1"
            >
              Voltar ao topo
              <ChevronUp className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="mt-8 text-center text-sm text-primary-foreground/70">
          2025 © Assessoria DOHA LTDA, CNPJ: 65.400.560/0001-89
        </div>
      </div>
    </footer>
  );
};

export default Footer;
